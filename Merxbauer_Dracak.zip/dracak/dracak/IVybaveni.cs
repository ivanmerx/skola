﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dracak
{
    public interface IVybaveni
    {
        string nazev { get; set; }
        int hodnotaUtoku { get; set; }
    }
}
